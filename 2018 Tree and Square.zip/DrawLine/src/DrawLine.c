/*
===============================================================================
 Name        : DrawLine.c
 Author      : $RJ
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
 */

#include <cr_section_macros.h>
#include <NXP/crp.h>
#include "LPC17xx.h"                        /* LPC17xx definitions */
#include "ssp.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>



/* Be careful with the port number and location number, because

some of the location may not exist in that port. */

#define PORT_NUM            0


uint8_t src_addr[SSP_BUFSIZE];
uint8_t dest_addr[SSP_BUFSIZE];


#define ST7735_TFTWIDTH 127
#define ST7735_TFTHEIGHT 159

#define ST7735_CASET 0x2A
#define ST7735_RASET 0x2B
#define ST7735_RAMWR 0x2C
#define ST7735_SLPOUT 0x11
#define ST7735_DISPON 0x29



#define swap(x, y) {x = x + y; y = x - y; x = x - y ;}

// defining color values

#define LIGHTBLUE 0x00FFE0
#define GREEN 0x00FF00
#define DARKBLUE 0x000033
#define BLACK 0x000000
#define BLUE 0x0007FF
#define RED 0xFF0000
#define MAGENTA 0x00F81F
#define WHITE 0xFFFFFF
#define PURPLE 0xCC33FF
#define BROWN 0X8B4513
#define TREEBROWN 0XDEB887


const int tree_depth= 5;
int _height = ST7735_TFTHEIGHT;
int _width = ST7735_TFTWIDTH;

const int size=1024;
//int tree_depth=5;
int x_cor[2048];
int y_cor[2048];
int tree_length=0;


void spiwrite(uint8_t c)

{

	int pnum = 0;

	src_addr[0] = c;

	SSP_SSELToggle( pnum, 0 );

	SSPSend( pnum, (uint8_t *)src_addr, 1 );

	SSP_SSELToggle( pnum, 1 );

}



void writecommand(uint8_t c)

{

	LPC_GPIO0->FIOCLR |= (0x1<<21);

	spiwrite(c);

}



void writedata(uint8_t c)

{

	LPC_GPIO0->FIOSET |= (0x1<<21);

	spiwrite(c);

}



void writeword(uint16_t c)

{

	uint8_t d;

	d = c >> 8;

	writedata(d);

	d = c & 0xFF;

	writedata(d);

}



void write888(uint32_t color, uint32_t repeat)

{

	uint8_t red, green, blue;

	int i;

	red = (color >> 16);

	green = (color >> 8) & 0xFF;

	blue = color & 0xFF;

	for (i = 0; i< repeat; i++) {

		writedata(red);

		writedata(green);

		writedata(blue);

	}

}



void setAddrWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1)

{

	writecommand(ST7735_CASET);

	writeword(x0);

	writeword(x1);

	writecommand(ST7735_RASET);

	writeword(y0);

	writeword(y1);

}


void fillrect(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint32_t color)

{

	int16_t width, height;

	width = x1-x0+1;

	height = y1-y0+1;

	setAddrWindow(x0,y0,x1,y1);

	writecommand(ST7735_RAMWR);

	write888(color,width*height);

}



void lcddelay(int ms)

{

	int count = 24000;

	int i;

	for ( i = count*ms; i--; i > 0);

}



void lcd_init()

{

	int i;
	printf("LCD Demo Begins!!!\n");
	// Set pins P0.16, P0.21, P0.22 as output
	LPC_GPIO0->FIODIR |= (0x1<<16);

	LPC_GPIO0->FIODIR |= (0x1<<21);

	LPC_GPIO0->FIODIR |= (0x1<<22);

	// Hardware Reset Sequence
	LPC_GPIO0->FIOSET |= (0x1<<22);
	lcddelay(500);

	LPC_GPIO0->FIOCLR |= (0x1<<22);
	lcddelay(500);

	LPC_GPIO0->FIOSET |= (0x1<<22);
	lcddelay(500);

	// initialize buffers
	for ( i = 0; i < SSP_BUFSIZE; i++ )
	{

		src_addr[i] = 0;
		dest_addr[i] = 0;
	}

	// Take LCD display out of sleep mode
	writecommand(ST7735_SLPOUT);
	lcddelay(200);

	// Turn LCD display on
	writecommand(ST7735_DISPON);
	lcddelay(200);

}




void drawPixel(int16_t x, int16_t y, uint32_t color)

{

	if ((x < 0) || (x >= _width) || (y < 0) || (y >= _height))

		return;

	setAddrWindow(x, y, x + 1, y + 1);

	writecommand(ST7735_RAMWR);

	write888(color, 1);

}



/*****************************************************************************


 ** Descriptions:        Draw line function

 **

 ** parameters:           Starting point (x0,y0), Ending point(x1,y1) and color

 ** Returned value:        None

 **

 *****************************************************************************/


void drawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint32_t color)

{

	int16_t slope = abs(y1 - y0) > abs(x1 - x0);

	if (slope) {

		swap(x0, y0);

		swap(x1, y1);

	}

	if (x0 > x1) {

		swap(x0, x1);

		swap(y0, y1);

	}

	int16_t dx, dy;

	dx = x1 - x0;

	dy = abs(y1 - y0);

	int16_t err = dx / 2;

	int16_t ystep;

	if (y0 < y1) {

		ystep = 1;

	}

	else {

		ystep = -1;

	}

	for (; x0 <= x1; x0++) {

		if (slope) {

			drawPixel(y0, x0, color);

		}

		else {

			drawPixel(x0, y0, color);

		}

		err -= dy;

		if (err < 0) {

			y0 += ystep;

			err += dx;

		}

	}

}


/*

 Main Function main()

 */

void drawSquare(int16_t x0,int16_t y0,int16_t x1,int16_t y1,int16_t x2,int16_t y2,int16_t x3,int16_t y3,uint32_t color){
	drawLine(x0,y0,x1,y1,color);
	drawLine(x1,y1,x2,y2,color);
	drawLine(x2,y2,x3,y3,color);
	drawLine(x3,y3,x0,y0,color);
}

void drawCircle(uint16_t r,uint16_t h,uint16_t k)
{
	int n=(2*r)+1;
	int m=0,m1=0;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			m=h-r+i;
			m1=k-r+j;
			if((((m-h)*(m-h)) +((m1-k)*(m1-k))) <= (r*r)+1)
			{
				drawPixel(m,m1,WHITE);
			}
		}
	}
}


void drawTree(int startx, int starty,int endx,int endy,int angle,uint32_t color){


	float deltax=endx-startx;
	float deltay=endy-starty;

	float alpha=angle * 3.141592653589/180;//0.56=30 2.61=150 1.57=90
	int resultx=0;
	int resulty=0;

	resultx = startx + ((deltax*cos(alpha))- (deltay*sin(alpha)));

	resulty = starty + ((deltax*sin(alpha))+ (deltay*cos(alpha)));

	drawLine(startx, starty, resultx, resulty, color);
	x_cor[tree_length]=resultx;
	y_cor[tree_length]=resulty;
	tree_length++;
	resultx = startx + ((deltax*cos(-alpha))- (deltay*sin(-alpha)));
	resulty = starty + ((deltax*sin(-alpha))+ (deltay*cos(-alpha)));
	drawLine(startx, starty, resultx, resulty, color);
	x_cor[tree_length]=resultx;
	y_cor[tree_length]=resulty;
	tree_length++;
}


#if 0
int main (void)

{

	uint32_t pnum = PORT_NUM;

	pnum = 0 ;

	if ( pnum == 0 )
		SSP0Init();

	else
		puts("Port number is not correct");

	lcd_init();

	fillrect(0, 0, ST7735_TFTWIDTH, ST7735_TFTHEIGHT-50,TREEBROWN );
	     fillrect(0,ST7735_TFTHEIGHT-50,ST7735_TFTWIDTH,ST7735_TFTHEIGHT,BLUE);
	      drawCircle(7,20,140);



	srand(time(0));
	int xxr[1024];
	int yyr[1024];
	int adder=20;
	int distance=50;
	float val=0.2;
	int range1=1+50-0;
	int range2=1+50-0;
	int	 x0 = rand()%range1;



	for(int mk=0;mk<40;mk++){
		int  y0 = rand()%range2;
	if(x0<20){
		x0=x0+30;
	}
	if(y0<20){
		y0=y0+100;
		adder=60;
		distance=30;
	}
	else{
		adder=20;
		distance=50;
	}
	   int dewx=x0;
	   int dewy=y0-adder;

	int x1=x0;
	int y1=y0+distance;
	drawLine(dewx, dewy, x0,y0, BROWN);
	drawLine(x0, y0, x1,y1, BROWN);
	lcddelay(500);
	drawLine(dewx-1, dewy, x0-1,y0, BROWN);
	drawLine(dewx-2, dewy, x0-2,y0, BROWN);
	drawLine(dewx+1, dewy, x0+1,y0, BROWN);
	drawLine(dewx+2, dewy, x0+2,y0, BROWN);
	drawLine(x0-1, y0, x1-1,y1-5, BROWN);
	drawLine(x0-2, y0, x1-2,y1-5, BROWN);
	drawLine(x0+1, y0, x1+1,y1-5, BROWN);
	drawLine(x0+2, y0, x1+2,y1-5, BROWN);
	int xr=x0+(val*(x1-x0));
	int yr=y0+(val*(y1-y0));
	int angle=30;
	drawTree(xr, yr, x1, y1, angle, BROWN);
	int score=0;

		int tt=0;
		while(tt<size){
		 xxr[tt]=xr+(val*(x_cor[tt]-xr));
		 yyr[tt]=yr+(val*(y_cor[tt]-yr));
		 drawTree(xxr[tt], yyr[tt], x_cor[tt], y_cor[tt], angle, GREEN);
		if(tt%2!=0){
			xr=xxr[score];
			yr=yyr[score];
			score++;

		}
		tt++;
	}
	x0=x0+30;
	tree_length=0;
	}
	return 0;

}

#endif

#if 1
int main (void)

{

	uint32_t pnum = PORT_NUM;

	pnum = 0 ;

	if ( pnum == 0 )
		SSP0Init();

	else
		puts("Port number is not correct");

	lcd_init();
    //int randnox=rand()%100; //to generate the random number
	//int randnoy=rand()%100;
    fillrect(0, 0, ST7735_TFTWIDTH, ST7735_TFTHEIGHT, BLACK);
	uint32_t my_colors[]={LIGHTBLUE,GREEN,PURPLE,MAGENTA};
    int input=0;
	int x0,x1,y0,y1,x2,y2,x3,y3;
	int m0,n0,m1,n1,m2,n2,m3,n3;
	float l=0.2;
	while(1)
	{

		int s0=rand()%55;
		int s1=rand()%100;
		int s2=10+rand()%70;
		x0= s0;
		y0=s1;

		x1=x0;
		y1=y0+s2;
		x2=x0+s2;
		y2=y0+s2;
		x3=x0+s2;
		y3=y0;
		drawSquare(x0,y0,x1,y1,x2,y2,x3,y3,WHITE);
		lcddelay(100);
		for(int i=0;i<9;i++)
		{
			m0=x0+l*(x1-x0);
			n0=y0+l*(y1-y0);
			m1=x1+l*(x2-x1);
			n1=y1+l*(y2-y1);
			m2=x2+l*(x3-x2);
			n2=y2+l*(y3-y2);
			m3=x3+l*(x0-x3);
			n3=y3+l*(y0-y3);
			drawSquare(m0,n0,m1,n1,m2,n2,m3,n3,my_colors[i%4]);
			lcddelay(10);
			x0=m0;
			y0=n0;
			x1=m1;
			y1=n1;
			x2=m2;
			y2=n2;
			x3=m3;
			y3=n3;
		}
	}

return 0;
}

#endif

#if 0
int main (void)

{
	uint32_t pnum = PORT_NUM;

	pnum = 0 ;

	if ( pnum == 0 )
		SSP0Init();

	else
		puts("Port number is not correct");

	lcd_init();



	fillrect(0, 0, ST7735_TFTWIDTH, ST7735_TFTHEIGHT-50,TREEBROWN );
	     fillrect(0,ST7735_TFTHEIGHT-50,ST7735_TFTWIDTH,ST7735_TFTHEIGHT,BLUE);
	      drawCircle(7,20,140);

	      while(1)
	      {


	srand(time(0));
	int xxr[1024];
	int yyr[1024];
	int adder=20;
	int distance=50;
	float val=0.2;
	int range1=1+50-0;
	int range2=1+50-0;
	int	 x0 = rand()%10;



	for(int mk=0;mk<5;mk++){
		int  y0 = rand()%range2;
	if(x0<20){
		x0=x0+30;
	}
	if(y0<20){
		y0=y0+100;
		adder=60;
		distance=30;
	}
	else{
		adder=20;
		distance=50;
	}
	   int dewx=x0;
	   int dewy=y0-adder;

	int x1=x0;
	int y1=y0+distance;
	drawLine(dewx, dewy, x0,y0, BROWN);
	drawLine(x0, y0, x1,y1, BROWN);
	lcddelay(500);
	drawLine(dewx-1, dewy, x0-1,y0, BROWN);
	drawLine(dewx-2, dewy, x0-2,y0, BROWN);
	drawLine(dewx+1, dewy, x0+1,y0, BROWN);
	drawLine(dewx+2, dewy, x0+2,y0, BROWN);
	drawLine(x0-1, y0, x1-1,y1-5, BROWN);
	drawLine(x0-2, y0, x1-2,y1-5, BROWN);
	drawLine(x0+1, y0, x1+1,y1-5, BROWN);
	drawLine(x0+2, y0, x1+2,y1-5, BROWN);
	int xr=x0+(val*(x1-x0));
	int yr=y0+(val*(y1-y0));
	int angle=30;
	drawTree(xr, yr, x1, y1, angle, BROWN);
	int score=0;

		int tt=0;
		while(tt<size){
		 xxr[tt]=xr+(val*(x_cor[tt]-xr));
		 yyr[tt]=yr+(val*(y_cor[tt]-yr));
		 drawTree(xxr[tt], yyr[tt], x_cor[tt], y_cor[tt], angle, GREEN);
		if(tt%2!=0){
			xr=xxr[score];
			yr=yyr[score];
			score++;

		}
		tt++;
	}
	//originLx0=x0+30;
	x0=x0+20;
	tree_length=0;
	}
	char ch = getchar();
	if(ch == 'q' || ch == 'Q') break;
	getchar();

	      }

	return 0;
}


#endif
